/**
 * The environment variables when the application is in production
 */
export const environment = {
  production: true
};
