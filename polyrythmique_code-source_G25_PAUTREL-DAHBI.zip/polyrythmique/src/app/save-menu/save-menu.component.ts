import { Component, OnInit } from '@angular/core';

/**
* The save-menu component <br/>
* TODO
*/
@Component({
  selector: 'app-save-menu',
  templateUrl: './save-menu.component.html',
  styleUrls: ['./save-menu.component.sass']
})
export class SaveMenuComponent implements OnInit {
  /**
   * @ignore
   */
  constructor() { }
  /**
   * @ignore
   */
  ngOnInit(): void {
  }

}
