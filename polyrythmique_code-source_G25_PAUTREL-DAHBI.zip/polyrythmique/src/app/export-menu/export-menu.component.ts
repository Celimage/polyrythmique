import { Component, OnInit } from '@angular/core';

/**
 * The menu that allows to exports a rythm <br/>
 * TODO
 */
@Component({
  selector: 'app-export-menu',
  templateUrl: './export-menu.component.html',
  styleUrls: ['./export-menu.component.sass']
})

export class ExportMenuComponent implements OnInit {
  /**
   * @ignore
   */
  constructor() { }
  /**
   * @ignore
   */
  ngOnInit(): void {
  }

}
